import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def extract(input: torch.Tensor, t: torch.Tensor, x: torch.Tensor):
    """Gather per-timestep scalars from a 1-D buffer and reshape to match x's batch/shape."""
    if t.ndim == 0:
        t = t.unsqueeze(0)
    shape = x.shape
    t = t.long().to(input.device)
    out = torch.gather(input, 0, t)
    reshape = [t.shape[0]] + [1] * (len(shape) - 1)
    return out.reshape(*reshape).to(x.dtype)


class BaseScheduler(nn.Module):
    """Variance scheduler of DDPM."""

    def __init__(
        self,
        num_train_timesteps: int,
        beta_1: float = 1e-4,
        beta_T: float = 0.02,
        mode: str = "linear",
    ):
        super().__init__()
        self.num_train_timesteps = num_train_timesteps
        self.timesteps = torch.from_numpy(
            np.arange(0, self.num_train_timesteps)[::-1].copy().astype(np.int64)
        )

        if mode == "linear":
            betas = torch.linspace(beta_1, beta_T, steps=num_train_timesteps)
        elif mode == "quad":
            betas = (
                torch.linspace(beta_1**0.5, beta_T**0.5, num_train_timesteps) ** 2
            )
        else:
            raise NotImplementedError(f"{mode} is not implemented.")

        alphas = 1 - betas
        alphas_cumprod = torch.cumprod(alphas, dim=0)

        self.register_buffer("betas", betas)
        self.register_buffer("alphas", alphas)
        self.register_buffer("alphas_cumprod", alphas_cumprod)


class DiffusionModule(nn.Module):
    """High-level DDPM wrapper with training and sampling utilities."""

    def __init__(self, network: nn.Module, var_scheduler: BaseScheduler):
        super().__init__()
        self.network = network
        self.var_scheduler = var_scheduler

    @property
    def device(self):
        return next(self.network.parameters()).device

    @property
    def image_resolution(self):
        return getattr(self.network, "image_resolution", None)

    # ------------------------
    # Forward noising process
    # ------------------------
    def q_sample(self, x0: torch.Tensor, t: torch.Tensor, noise: torch.Tensor | None = None):
        """q(x_t | x_0) = N( sqrt(alpha_bar_t) * x_0, (1 - alpha_bar_t) I )."""
        if noise is None:
            noise = torch.randn_like(x0)

        alpha_bar_t = extract(self.var_scheduler.alphas_cumprod, t, x0)
        xt = torch.sqrt(alpha_bar_t) * x0 + torch.sqrt(1.0 - alpha_bar_t) * noise
        return xt

    # ------------------------
    # Reverse denoising step
    # ------------------------
    @torch.no_grad()
    def p_sample(self, xt: torch.Tensor, t: int | torch.Tensor):
        """DDPM reverse update: x_{t-1} from x_t at timestep t."""
        if isinstance(t, int):
            t = torch.tensor([t], device=self.device, dtype=torch.long)
        else:
            t = t.to(self.device).long()

        # buffers
        alpha_t = extract(self.var_scheduler.alphas, t, xt)
        alpha_bar_t = extract(self.var_scheduler.alphas_cumprod, t, xt)

        alphas_cumprod = self.var_scheduler.alphas_cumprod
        alpha_bar_prev_all = torch.cat(
            [
                torch.ones(1, device=alphas_cumprod.device, dtype=alphas_cumprod.dtype),
                alphas_cumprod[:-1],
            ],
            dim=0,
        )
        alpha_bar_prev = extract(alpha_bar_prev_all, t, xt)
        beta_t = extract(self.var_scheduler.betas, t, xt)

        # predict epsilon_theta(xt, t)
        eps_theta = self.network(xt, t)

        # mean term
        eps_factor = (1 - alpha_t) / torch.sqrt(1 - alpha_bar_t)
        mean = (1.0 / torch.sqrt(alpha_t)) * (xt - eps_factor * eps_theta)

        # variance (posterior)
        posterior_var = (1 - alpha_bar_prev) / (1 - alpha_bar_t) * beta_t

        # add noise for t>0
        noise = torch.randn_like(xt)
        # Broadcast mask to match xt's batch dims
        if t.ndim == 1 and t.shape[0] == xt.shape[0]:
            nonzero_mask = (t > 0).float().view(-1, *[1] * (xt.dim() - 1))
        else:
            nonzero_mask = (t > 0).float().view(1, *[1] * (xt.dim() - 1))

        x_t_prev = mean + nonzero_mask * torch.sqrt(posterior_var) * noise
        return x_t_prev

    @torch.no_grad()
    def p_sample_loop(self, shape: tuple[int, ...]):
        """Algorithm 2 in DDPM: start from x_T ~ N(0, I) then iterate t = T-1 ... 0."""
        xt = torch.randn(shape, device=self.device)
        for t in self.var_scheduler.timesteps.to(self.device):
            xt = self.p_sample(xt, int(t.item()))
        return xt  # interpreted as x_0

    # ------------------------
    # Training loss
    # ------------------------
    def compute_loss(self, x0: torch.Tensor):
        """E_{t, eps}[ || eps - eps_theta(x_t, t) ||^2 ] (Eq. 14)."""
        batch = x0.shape[0]
        t = torch.randint(
            0, self.var_scheduler.num_train_timesteps, size=(batch,), device=x0.device
        ).long()
        eps = torch.randn_like(x0)
        xt = self.q_sample(x0, t, noise=eps)
        eps_pred = self.network(xt, t)
        loss = F.mse_loss(eps_pred, eps)
        return loss

    # ------------------------
    # Checkpoint utils
    # ------------------------
    def save(self, file_path: str):
        hparams = {
            "network": self.network,
            "var_scheduler": self.var_scheduler,
        }
        state_dict = self.state_dict()
        torch.save({"hparams": hparams, "state_dict": state_dict}, file_path)

    def load(self, file_path: str):
        dic = torch.load(file_path, map_location="cpu")
        hparams = dic["hparams"]
        state_dict = dic["state_dict"]
        self.network = hparams["network"]
        self.var_scheduler = hparams["var_scheduler"]
        self.load_state_dict(state_dict)
